# Disable camera shutter and screenshot sound

This module systemlessly replaces the sound file with an empty version.
